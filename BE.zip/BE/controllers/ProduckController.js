import Produck from "../models/ProduckModel.js";

export const getProducks = async(req, res) =>{
    try {
        const response = await Produck.findAll();
        res.status(200).json(response);
    } catch (error) {
        console.log(error.message);
    }
}

export const getProduckById = async(req, res) =>{
    try {
        const response = await Produck.findOne({
            where:{
                id: req.params.id
            }
        });
        res.status(200).json(response);
    } catch (error) {
        console.log(error.message);
    }
}

export const createProduck = async(req, res) =>{
    try {
        await Produck.create(req.body);
        res.status(201).json({msg: "Produck Created"});
    } catch (error) {
        console.log(error.message);
    }
}

export const updateProduck = async(req, res) =>{
    try {
        await Produck.update(req.body,{
            where:{
                id: req.params.id
            }
        });
        res.status(200).json({msg: "Produck Updated"});
    } catch (error) {
        console.log(error.message);
    }
}

export const deleteProduck = async(req, res) =>{
    try {
        await Produck.destroy({
            where:{
                id: req.params.id
            }
        });
        res.status(200).json({msg: "Produck Deleted"});
    } catch (error) {
        console.log(error.message);
    }
}

