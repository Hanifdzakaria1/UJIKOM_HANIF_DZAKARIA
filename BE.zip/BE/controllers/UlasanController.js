import Ulasan from "../models/UlasanModel.js";

export const getUlasans = async(req, res) =>{
    try {
        const response = await Ulasan.findAll();
        res.status(200).json(response);
    } catch (error) {
        console.log(error.message);
    }
}

export const getUlasanById = async(req, res) =>{
    try {
        const response = await Ulasan.findOne({
            where:{
                id: req.params.id
            }
        });
        res.status(200).json(response);
    } catch (error) {
        console.log(error.message);
    }
}

export const createUlasan = async(req, res) =>{
    try {
        await Ulasan.create(req.body);
        res.status(201).json({msg: "Ulasan Created"});
    } catch (error) {
        console.log(error.message);
    }
}

export const updateUlasan = async(req, res) =>{
    try {
        await Ulasan.update(req.body,{
            where:{
                id: req.params.id
            }
        });
        res.status(200).json({msg: "Ulasan Updated"});
    } catch (error) {
        console.log(error.message);
    }
}

export const deleteUlasan = async(req, res) =>{
    try {
        await Ulasan.destroy({
            where:{
                id: req.params.id
            }
        });
        res.status(200).json({msg: "Ulasan Deleted"});
    } catch (error) {
        console.log(error.message);
    }
}

