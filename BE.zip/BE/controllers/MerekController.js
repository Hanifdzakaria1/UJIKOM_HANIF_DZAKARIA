import Merek from "../models/MerekModel.js";

export const getMereks = async(req, res) =>{
    try {
        const response = await Merek.findAll();
        res.status(200).json(response);
    } catch (error) {
        console.log(error.message);
    }
}

export const getMerekById = async(req, res) =>{
    try {
        const response = await Merek.findOne({
            where:{
                id: req.params.id
            }
        });
        res.status(200).json(response);
    } catch (error) {
        console.log(error.message);
    }
}

export const createMerek = async(req, res) =>{
    try {
        await Merek.create(req.body);
        res.status(201).json({msg: "Merek Created"});
    } catch (error) {
        console.log(error.message);
    }
}

export const updateMerek = async(req, res) =>{
    try {
        await Merek.update(req.body,{
            where:{
                id: req.params.id
            }
        });
        res.status(200).json({msg: "Merek Updated"});
    } catch (error) {
        console.log(error.message);
    }
}

export const deleteMerek = async(req, res) =>{
    try {
        await Merek.destroy({
            where:{
                id: req.params.id
            }
        });
        res.status(200).json({msg: "Merek Deleted"});
    } catch (error) {
        console.log(error.message);
    }
}

