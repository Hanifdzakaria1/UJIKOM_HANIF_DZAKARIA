import {Sequelize} from "sequelize";
import db from "../config/Database.js";

const {DataTypes} = Sequelize;

const Produck = db.define('producks',{
    nameProduck: DataTypes.STRING,
    Deskripsion: DataTypes.STRING
},{
    freezeTableName:true
});

export default Produck;

(async()=>{
    await db.sync();
})();