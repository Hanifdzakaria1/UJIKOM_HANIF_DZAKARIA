import {Sequelize} from "sequelize";
import db from "../config/Database.js";

const {DataTypes} = Sequelize;

const Admin = db.define('admins',{
    nameAdmin: DataTypes.STRING,
    emailAdmin: DataTypes.STRING,
    status: DataTypes.STRING
},{
    freezeTableName:true
});

export default Admin;

(async()=>{
    await db.sync();
})();