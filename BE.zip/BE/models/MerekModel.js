import {Sequelize} from "sequelize";
import db from "../config/Database.js";

const {DataTypes} = Sequelize;

const Merek = db.define('mereks',{
    jenisProduck: DataTypes.STRING,
    NilaiProduck: DataTypes.STRING,
},{
    freezeTableName:true
});

export default Merek;

(async()=>{
    await db.sync();
})();