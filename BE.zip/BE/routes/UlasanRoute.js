import express from "express";
import {
    getUlasans, 
    getUlasanById,
    createUlasan,
    updateUlasan,
    deleteUlasan
} from "../controllers/UlasanController.js";

const router = express.Router();

router.get('/ulasans', getUlasans);
router.get('/ulasans/:id', getUlasanById);
router.post('/ulasans', createUlasan);
router.patch('/ulasans/:id', updateUlasan);
router.delete('/ulasans/:id', deleteUlasan);

export default router;