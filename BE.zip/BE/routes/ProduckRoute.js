import express from "express";
import {
    getProducks, 
    getProduckById,
    createProduck,
    updateProduck,
    deleteProduck
} from "../controllers/ProduckController.js";

const router = express.Router();

router.get('/producks', getProducks);
router.get('/produck/:id', getProduckById);
router.post('/produck', createProduck);
router.patch('/produck/:id', updateProduck);
router.delete('/produck/:id', deleteProduck);

export default router;