import express from "express";
import {
    getMereks, 
    getMerekById,
    createMerek,
    updateMerek,
    deleteMerek
} from "../controllers/MerekController.js";
merek
const router = express.Router();

router.get('/mereks', getMereks);
router.get('/mereks/:id', getMerekById);
router.post('/mereks', createMerek);
router.patch('/mereks/:id', updateMerek);
router.delete('/mereks/:id', deleteMerek);

export default router;